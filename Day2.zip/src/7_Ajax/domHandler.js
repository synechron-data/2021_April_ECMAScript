import apiClient from "./apiClient";

var button = document.createElement("button");
button.innerHTML = "GET DATA";
button.className = "btn btn-primary";

var btnArea = document.createElement("div");
btnArea.className = "row mt-3";
btnArea.appendChild(button);

var body = document.getElementsByTagName('body')[0];
body.className = "container";
body.appendChild(btnArea);

var table = document.createElement('table');
table.id = "postTable";

var tblHead = document.createElement('thead');
var rowHead = document.createElement('tr');
table.appendChild(tblHead);
tblHead.appendChild(rowHead);

var tableArea = document.createElement("div");
tableArea.className = "row mt-3";
tableArea.appendChild(table);

body.appendChild(tableArea);

// button.addEventListener("click", function () {
//     // alert("Button Clicked...");

//     // apiClient.getAllPosts((data) => {
//     //     console.log(data);
//     // }, (emsg) => {
//     //     console.error(emsg);
//     // });

//     apiClient.getAllPostsUsingPromise().then((data) => {
//         generateTable(data);
//     }).catch((emsg) => {
//         console.error(emsg);
//     });
// });

button.addEventListener("click", async function () {
    try {
        var data = await apiClient.getAllPostsUsingPromise();
        generateTable(data);
    }
    catch (e) {
        console.error(e);
    }
});

function generateTable(data) {
    let table = document.getElementById("postTable");
    let row, cell;

    for (let i = 0; i < data.length; i++) {
        row = table.insertRow();
        cell = row.insertCell();
        cell.textContent = data[i].id;
        cell = row.insertCell();
        cell.textContent = data[i].title;
        cell = row.insertCell();
        cell.textContent = data[i].body;
    }
}

