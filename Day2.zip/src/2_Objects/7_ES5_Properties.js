// Properties are easier way of accessing and mutating your data members

const Person = (function () {
    function Person(name, age) {
        this._name = name;
        this._age = age;
    }

    Object.defineProperty(Person.prototype, "Name", {
        get: function () {
            return this._name;
        },
        set: function (value) {
            this._name = value;
        }
    });

    Object.defineProperty(Person.prototype, "Age", {
        get: function () {
            return this._age;
        },
        set: function (value) {
            this._age = value;
        }
    });

    return Person;
})();

var p1 = new Person("Manish", 10);
console.log(p1.Name);
console.log(p1.Age);
p1.Name = "Abhijeet";
p1.Age = 20;
console.log(p1.Name);
console.log(p1.Age);