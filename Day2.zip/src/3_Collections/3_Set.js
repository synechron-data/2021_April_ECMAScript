// var mySet = new Set();

// // console.log(mySet);
// // console.log(typeof mySet);
// // console.log(mySet.size);

// mySet.add(1);
// mySet.add(2);
// mySet.add(3);
// mySet.add(4);
// mySet.add(5);

// mySet.add(1);
// mySet.add(2);
// mySet.add(3);
// mySet.add(6);
// mySet.add(7);

// for (const item of mySet) {
//     console.log(item);
// }

var numbers = [10, 20, 30, 40, 50, 10, 20, 30, 21, 56, 40, 50, 30, 40, 50, 11, 33];

var set = new Set(numbers);
var uNumbers = Array.from(set);

console.log(numbers);
console.log(uNumbers);