// // function* idGenerator(){
// //     yield 1;
// //     yield 2;
// //     yield 3;
// // }

// // let seq = idGenerator();
// // console.log(seq.next());
// // console.log(seq.next());
// // console.log(seq.next());
// // console.log(seq.next());

// function* idGenerator() {
//     console.log("First Line");
//     yield 1;
//     console.log("Started after yield 1");
//     yield 2;
//     console.log("Started after yield 2");
//     yield 3;
// }

// let seq = idGenerator();

// do {
//     var obj = seq.next();
//     console.log(obj.value);
//     console.log("\n");
// } while (!obj.done);

// ---------------------------------------------------------

class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];            
    //     }   
    // }
    
    *[Symbol.iterator]() {
        yield* this._dataArray;
    }
}

let numbersQ = new Queue();
numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);

for (const n of numbersQ) {
    console.log(n);
}