'use strict'
// console.log("Hello from Declarations file!");

// var a = 10;
// var a;
// console.log("a: ", a);

// Hoisting - Hoisting is JavaScript's Runtime default behavior of 
// moving declarations to the top.

// a = 10;
// console.log("a: ", a);
// var a;

// Not Typesafe
// var a = 10;
// console.log("a: ", a);
// a = "Hello";
// console.log("a: ", a);

// var a = 10;
// var a = "Hello";
// console.log("a: ", a);

// var keyword does not give block scoping, 
// Only Global and Function Scope is supported when using var keyword

// function test() {
//     var a = "Manish";
//     console.log("Inside:", a);
// }
// test();

// console.log("Outside:", a);

var i = "Hello";
console.log("Before, i: ", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is: ", i)
// }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside Loop, _i is: ", _i)
// }

// function iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is: ", i)
//     }
// }

// iterate();

// IIFE - Immediatly Invoked Function Expression
(function () {
    for (var i = 0; i < 5; i++) {
        console.log("Inside Loop, i is: ", i)
    }
})();

console.log("After, i: ", i);