// let a;
// let a = 10;
// console.log("a is:", a);

// a = "Hello";
// console.log("a is:", a);

// You cannot declare same named variable in same scope using let keyword
// let a = 10
// let a = "Hello";                // Identifier 'a' has already been declared
// console.log("a is:", a);

// let keyword is not hoisted
// a = 10;                         // Cannot access 'a' before initialization
// console.log("a: ", a);
// let a;

// ES 2015 with let keyword supports
// Global Scope
// Function (local) Scope
// Block Scope

let i = "Hello";
console.log("Before, i: ", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is: ", i)
}

console.log("After, i: ", i);