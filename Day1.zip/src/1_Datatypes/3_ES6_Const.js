// let a;
// console.log(a);

// const env;                  // Error: Const declarations require an initialization value
// console.log(env);

// const env = "dev";
// console.log(env);

// env = "prod";                   // Error: Assignment to constant variable.
// console.log(env);


// -------------------------------------------

// const env = "dev";
// console.log(env);

// if (true) {
//     const env = "prod";                  
//     console.log(env);
// }

// -------------------------------------------

const obj = { id: 1 };
console.log(obj);

obj.id = 1000;
obj.name = "Manish";
// obj = {};                // Error: Assignment to constant variable.
console.log(obj);
