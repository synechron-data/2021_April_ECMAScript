var language;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = null;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = 10;
// language = 10.5;
// language = 0b1010;
// language = 0o1010;
// language = 0x1010;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';
// ECMASCRIPT 2015 - Template / String Literal (BackTick)
// language = `Java
// Script`;   

var d1 = "Java";
var d2 = "Script";
// language = "Hello from, " + d1 + d2 + " World!";
language = `Hello from, ${d1}${d2} World!`;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = true;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// ECMASCRIPT 2015 - Symbol
language = Symbol("Hello");
// language = new Symbol("Hello");         // Error: Symbol is not a constructor
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new Object();
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = String("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new String("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// console.log(Number.MAX_SAFE_INTEGER);
// console.log(Number.MIN_SAFE_INTEGER);
