var a = 54;
var b = "54";

console.log(typeof a);
console.log(typeof b);

var result = a == b;        // Abstract Equality
console.log(result);

result = a === b;        // Strict Equality
console.log(result);

var obj1 = { id: 1 };
var obj2 = { id: 1 };
var obj3 = obj1;

console.log(obj1 == obj2);
console.log(obj1 === obj2);

console.log(obj1 == obj3);
console.log(obj1 === obj3);
