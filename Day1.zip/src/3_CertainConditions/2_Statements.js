// if (condition)
//     Single Statement

// if (condition) {
//     Statements
// }

// if (condition) {
//     Statements
// } else {
//     Statements
// }

// if (condition) {
//     Statements
// } else if (condition) {
//     Statements
// } else {
//     Statements
// }

// var time = new Date().getHours();

// if (time < 20) {
//     console.log("Good Day");
// } else {
//     console.log("Good Evening");
// }

// if (time < 10) {
//     console.log("Good Morning");
// } else if (time < 20) {
//     console.log("Good Day");
// } else {
//     console.log("Good Evening");
// }

// ---------------------------------------------------------------------

// switch (expression) {
//     case "One":
//         break;
//     case "Two":
//         break;
//     case "Three":
//         break;
//     default:
//         break;
// }

// switch (expression) {
//     case 1:
//         break;
//     case 2:
//         break;
//     case 3:
//         break;
//     default:
//         break;
// }

var expr = window.prompt("Please give a fruit name", "Apples");

switch (expr) {
    case 'Oranges':
        console.log('Oranges are $0.59 a pound.');
        break;
    case 'Apples':
        console.log('Apples are $0.32 a pound.');
        break;
    case 'Bananas':
        console.log('Bananas are $0.48 a pound.');
        break;
    case 'Cherries':
        console.log('Cherries are $3.00 a pound.');
        break;
    case 'Mangoes':
        // console.log('Mangoes are $3.50 a pound.');
        // break;
    case 'Papayas':
        console.log('Mangoes and papayas are $2.79 a pound.');
        break;
    default:
        console.log('Sorry, we are out of ' + expr + '.');
}