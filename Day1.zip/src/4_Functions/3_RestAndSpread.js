// If I use ... on Lefthand side of assignment Operator (Rest)
// If I use ... on Righthand side of assignment Operator (Spread)

// In ECMAScript 2015, we can use ... only with Iterable Objects
// In ECMAScript 2018, we can use ... with Objects also

// ----------------------------------------------------------------- Array Spread

// var arr1 = [10, 20, 30, 40, [50, 60, 70, 80, 90]];

// // Refrence Copy
// // var arr2 = arr1;

// // Shallow Copy
// // var arr2 = arr1.slice();
// // var arr2 = [].concat(arr1);
// var arr2 = [...arr1];

// // Deep Copy
// // var arr2 = JSON.parse(JSON.stringify(arr1));

// arr2[0] = 1000;
// arr2[4][0] = 5000;

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);

// -----------------------------

// var arr1 = [10, 20, 30, 40];
// var arr2 = [50, 60, 70, 80];

// // var arr3 = [].concat(arr1, arr2);
// // var arr3 = arr1.concat(arr2);
// var arr3 = [...arr1, ...arr2];

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);
// console.log("Array 3", arr3);

// ----------------------------------------------------------------- Array Destructuring & Rest

// var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// ES 5 Destructuring

// var x = arr[0];
// var y = arr[1];

// ECMASCRIPT 2015 - Destructuring
// var [x, y] = arr;
// var [x, , y] = arr;

// console.log(`x = ${x}, y = ${y}`);

// ECMASCRIPT 2015 - Destructuring with Rest
// var [x, y, ...z] = arr;

// console.log(`x = ${x}, y = ${y}`);
// console.log("z = ", z);

// ----------------------------------------------------------------- Object Spread (2018)

// var person1 = { id: 1, name: "Manish", address: { city: "Pune", state: "MH", pin: 411021 } };

// Reference Copy
// var person2 = person1;

// Shallow Copy
// var person2 = Object.assign({}, person1);           // ECMASCRIPT 2015
// var person2 = { ...person1 };                       // Object Spread (ECMASCRIPT 2018)

// Deep Copy
// var person2 = JSON.parse(JSON.stringify(person1));

// person2.id = 1000;
// person2.address.city = "Mumbai";

// console.log("Person 1", person1);
// console.log("Person 2", person2);

// ----------------------------------------------------------------- Object Destructuring with Rest (2018)

var person = { id: 1, name: "Manish", city: "Pune", state: "MH", pin: 411021 };

// ES5 Destrucring
// var id = person.id;
// var name = person.name;

// ECMASCRIPT2015 Destrucring
// var { id, name } = person;

// ECMASCRIPT2015 Destrucring with REST

var { id, name, ...address } = person;

console.log(`Id: ${id}`);
console.log(`Name: ${name}`);
console.log(`Address: ${JSON.stringify(address)}`);