// Create Add function to accept 2 or 3 arguments (Overloading)

console.log(Add(2, 3));
console.log(Add(2, 3, 4));
console.log(Add(2));        // Show Error, if you are passing less than 2 or more than 3 arguments


// -----------------------------------------------------------------------------------
// Implement filter method, without using array.filter(), do Pure implementation

var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    
}

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);                 // ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];