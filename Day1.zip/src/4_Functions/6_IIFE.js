// function hello() {
//     console.log("Hello World!");
// }

// hello();

// function hello(name) {
//     console.log("Hello,", name);
// }

// hello("Manish");

// ------------------------------------------------------ IIFE - Immediatly Invoked Function Expression

// (function () {
//     console.log("Hello World!");
// })();

// (function () {
//     console.log("Hello World!");
// }());

// (() => {
//     console.log("Hello World!");
// })();

(function (name) {
    console.log("Hello,", name);
})("Subodh");

(function (name) {
    console.log("Hello,", name);
}("Manish"));

((name) => {
    console.log("Hello,", name);
})("Abhijeet");